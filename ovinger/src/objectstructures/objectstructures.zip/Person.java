package objectstructures;

public class Person {
	
}
